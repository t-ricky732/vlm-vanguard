import os
import json
import zipfile
import io
import hashlib
from pathlib import Path
from typing import Dict, List, Optional
from PIL import Image, UnidentifiedImageError
import torch
from torch.utils.data import Dataset
import logging
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ChartDataset")

class ChartDataset(Dataset):
    """Dataset for chart question-answering tasks with image and text pairs."""
    
    def __init__(
        self, 
        data_dir: str = "./chartllama_data", 
        processor = None, 
        image_size: int = 384, 
        sample_limit: Optional[int] = None,
        max_answer_length: int = 64,
        cache_processed: bool = True,
        cache_images: bool = False,
        skip_bad_examples: bool = True
    ):
        self.processor = processor
        self.image_size = image_size
        self.data = []
        self.cache_processed = cache_processed
        self.processed_cache = {}
        self.image_cache = {} if cache_images else None
        self.max_answer_length = max_answer_length
        self.skip_bad_examples = skip_bad_examples
        self.stats = self._init_stats()
        
        data_dir = Path(data_dir)
        if not data_dir.exists():
            raise FileNotFoundError(f"Data directory not found: {data_dir}")
        
        # Extract images from zip if needed
        self._extract_images(data_dir)
        
        # Load JSON files
        json_files = list(data_dir.glob('*.json'))
        self.stats['total_files'] = len(json_files)
        
        if len(json_files) == 0:
            logger.warning(f"No JSON files found in {data_dir}")
        
        sample_count = 0
        
        # Process files and examples
        for json_file in tqdm(json_files, desc="Loading JSON files"):
            try:
                examples = self._load_json(json_file)
                if not examples:
                    continue
                
                chart_type = json_file.stem.split('_')[0] if '_' in json_file.name else 'unknown'
                
                for i, example in enumerate(examples):
                    if sample_limit and sample_count >= sample_limit:
                        break
                    
                    self.stats['total_examples'] += 1
                    item = self._process_example(example, chart_type, json_file, i)
                    
                    if item:
                        self.data.append(item)
                        sample_count += 1
                    else:
                        self.stats['bad_examples'] += 1
                    
            except Exception as e:
                self.stats['error_files'] += 1
                logger.error(f"Error processing {json_file}: {e}")
        
        logger.info(f"Loaded {len(self.data)} examples")
        
    def _init_stats(self):
        return {
            'total_files': 0, 'error_files': 0, 'total_examples': 0,
            'bad_examples': 0, 'missing_images': 0, 'image_errors': 0, 
            'dummy_images': 0, 'truncated_answers': 0
        }
        
    def _load_json(self, json_file):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error reading {json_file}: {e}")
            self.stats['error_files'] += 1
            return None
            
    def _extract_images(self, data_dir):
        zip_path = data_dir / 'ours.zip'
        self.image_base_dir = data_dir
        
        if zip_path.exists():
            extract_dir = data_dir / 'extracted_images'
            extract_dir.mkdir(exist_ok=True)
            
            if not any(extract_dir.iterdir()):
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
            
            self.image_base_dir = extract_dir
    
    def _process_example(self, example, chart_type, json_file, example_idx):
        if not isinstance(example, dict) or 'conversations' not in example:
            return None
            
        try:
            question = example['conversations'][0]['value']
            answer = example['conversations'][1]['value']
            
            if not question.strip() or not answer.strip():
                return None
                
            if "<image>" not in question:
                question += " <image>"
            
            image_path = example.get('image', '')
            example_id = hashlib.md5(f"{json_file}_{example_idx}_{question[:50]}".encode()).hexdigest()
            image = self._load_image(image_path, chart_type, example_id)
            
            if image is None:
                return None
                
            return {
                'image': image,
                'text': question,
                'answer': answer,
                'chart_type': chart_type,
                'example_id': example_id
            }
        except Exception as e:
            logger.warning(f"Error processing example: {e}")
            return None
    
    def _load_image(self, image_path, chart_type, example_id):
        # Check cache first
        if self.image_cache is not None and example_id in self.image_cache:
            return self.image_cache[example_id]
            
        # Find and load image, with fallback to dummy
        if image_path:
            possible_paths = [
                self.image_base_dir / image_path,
                self.image_base_dir / os.path.basename(image_path),
                Path(image_path)
            ]
            
            for path in possible_paths:
                if path.exists():
                    try:
                        image = Image.open(path).convert('RGB')
                        image = image.resize((self.image_size, self.image_size), Image.LANCZOS)
                        
                        if self.image_cache is not None:
                            self.image_cache[example_id] = image
                        return image
                    except Exception:
                        self.stats['image_errors'] += 1
        
        # Create dummy image as fallback
        self.stats['dummy_images'] += 1
        from PIL import ImageDraw
        img = Image.new('RGB', (self.image_size, self.image_size), color=(200, 200, 200))
        draw = ImageDraw.Draw(img)
        draw.text((10, 10), f"DUMMY {chart_type.upper()} CHART", fill=(0, 0, 0))
        
        if self.image_cache is not None:
            self.image_cache[example_id] = img
        return img
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        if self.cache_processed and idx in self.processed_cache:
            return self.processed_cache[idx]
            
        item = self.data[idx]
        
        if self.processor is None:
            return item
        
        try:
            # Process image and text
            model_inputs = self.processor(
                text=item['text'],
                images=item['image'],
                return_tensors="pt"
            )
            
            # Process answer for training
            input_ids = model_inputs["input_ids"].squeeze(0)
            answer_ids = self.processor.tokenizer(
                item['answer'], 
                return_tensors="pt",
                max_length=self.max_answer_length,
                truncation=True
            ).input_ids.squeeze(0)
            
            # Create labels tensor
            labels = torch.full_like(input_ids, -100)
            seq_len, ans_len = input_ids.size(0), answer_ids.size(0)
            start_pos = max(0, seq_len - ans_len)
            labels[start_pos:seq_len] = answer_ids[:seq_len-start_pos]
            
            # Remove batch dimension
            for k, v in model_inputs.items():
                if isinstance(v, torch.Tensor):
                    model_inputs[k] = v.squeeze(0)
            
            model_inputs["labels"] = labels
            
            if self.cache_processed:
                self.processed_cache[idx] = model_inputs
            
            return model_inputs
        except Exception as e:
            logger.error(f"Error processing item {idx}: {e}")
            if self.skip_bad_examples and idx > 0:
                return self[idx-1]
            raise